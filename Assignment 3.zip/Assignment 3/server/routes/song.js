let express = require('express');
let router = express.Router();
let mongoose = require('mongoose');


//connect with song model

let Song = require('../models/song');

/*CRUD Operation*/
/* Read Operation */
/* Get route for the song list */

router.get('/',(req,res,next)=>{
  Song.find((err, songlist)=>{
    if (err)
    {
      return console.error(err);
    }
    else
    {
      //console.log(Songlist);
      res.render('song/list', {
        title:'Songs', 
        Songlist: songlist
      });

    }
  });
});

/*Add Operation*/
/*Get route for displaying the Add-Page -- Create Operation */
/*Post route for processing the Add-page -- Create Operation */

router.get('/add', (req, res, next)=>{
  res.render('song/add', {title:'Add Song'})

});
/*Post route for processing the Add-Page -- Create Operation*/
router.post('/add', (req, res, next)=>{
  let newSong = Song({
    "name":req.body.name,
    "singer":req.body.singer,
    "released":req.body.released,
    "email":req.body.email,
    "price":req.body.price
  });
  Song.create(newSong,(err,Song)=>{
    if(err)
    {
      console.log(err);
      res.end(err);
    }
    else{
      res.redirect('/song-list');
    }
  })

});


/*Edit Operation*/
/* Get route for displaying the Edit Operation -- Update Operation */
/* Post route for displaying the Edit Operation -- Update Operation */

router.get('/edit/:id', (req,res,next)=>{
  let id = req.params.id;
  Song.findById(id,(err,songToEdit)=>{
    if(err)
    {
      console.log(err);
      res.end(err);
    }
    else
    {
      res.render('song/edit',{title:'Edit Song', song:songToEdit});
    }
  })

});

router.post('/edit/:id', (req,res,next)=>{
  let id = req.params.id;
  let updateSong = Song({
    "_id":id,
    "name":req.body.name,
    "singer":req.body.singer,
    "released":req.body.released,
    "email":req.body.email,
    "price":req.body.price
  });
  Song.updateOne({_id:id},updateSong,(err)=>{
    if(err)
    {
      console.log(err);
      res.end(err);
    }
    else
    {
      res.redirect('/song-list');
    }
  })

});

/*Delete Operation*/
/*Get to perform Delete Operation -- Delete Operation*/
router.get('/delete/:id', (req,res,next)=>{
  let id = req.params.id;
  Song.deleteOne({_id:id}, (err)=>{
    if(err)
    {
      console.log(err);
      res.end(err);
    }
    else{
      res.redirect('/song-list');
    }
  })

});



module.exports=router;