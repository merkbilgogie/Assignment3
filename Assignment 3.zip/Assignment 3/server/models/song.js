let mongoose = require('mongoose');
//create a song model

let songModel = mongoose.Schema({
  name: String,
  singer: String,
  released: String,
  email: String,
  price: Number

},
{
  collection: "songs"
}

);

module.exports = mongoose.model('Song', songModel);

